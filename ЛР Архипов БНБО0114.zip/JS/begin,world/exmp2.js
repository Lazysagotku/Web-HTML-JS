function clrscr() {
  var par=document.getElementById('par');
  par.style.color='red';
}

function blck() {
  var par=document.getElementById('par');
  par.style.color='black';
}