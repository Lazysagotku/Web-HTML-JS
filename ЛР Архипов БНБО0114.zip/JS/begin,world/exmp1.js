function showmassage() {
     var message;
     message='Hello';
     var message2 = 'world';
     alert (message + ' ' + message2);
     var x = '16', y = 20;
     alert(+x + y);
     var bool = true;
     var arr = {name: '����',
                surname: '������'};
     if (bool) {
         alert(arr.name);
     }
     else {
          alert(arr.surname);
     }
}