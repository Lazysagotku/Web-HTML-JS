function reset(text) {
    text.value = "";
}
function calc() {
    var first = document.getElementById('first'),
        second = document.getElementById('second');
    var x = first.value,
        y = second.value;
    var select = document.getElementById('select');
    var selected = select.options[select.selectedIndex].value;
    switch (selected) {
        case '+':
            z = +x + +y;
            break;
        case '-':
            z = +x - +y;
            break;
        case '*':
            z = +x * +y;
            break;
        case '/':
            z = +x / +y;
    }
    reset(first);
    reset(second);
    rezult = '<p>' + x + selected + y + ' = ' + z + '</p>';
    var rez = document.getElementById('rez');
    rez.insertAdjacentHTML('AfterEnd', rezult);
}